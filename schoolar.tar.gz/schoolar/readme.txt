Superposition Hack
